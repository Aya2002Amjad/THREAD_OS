#include <iostream>
#include <pthread.h>
#include <fstream>
#include <iomanip>
using namespace std;

long aboveThreshold=0, equalThreshold=0, belowThreshold=0, id=0;
double initVal, threshold, currVal;
pthread_mutex_t mutex1;
pthread_mutex_t mutex2;
pthread_mutex_t mutex3;
pthread_mutex_t mutex4;
pthread_mutex_t mutex5;


void * multiply(void *value){
    double num = *(double*) value;

    pthread_mutex_lock(&mutex1);
    printf("Multiplier ThreadID= %ld, currentValue= %.6f -- multiplying %.6f\n",id++,currVal,num);
    pthread_mutex_unlock(&mutex1);
    
   pthread_mutex_lock(&mutex2);
    currVal*=num;
   pthread_mutex_unlock(&mutex2);
   
    if (currVal > threshold){
          pthread_mutex_lock(&mutex3);
          aboveThreshold++;
          pthread_mutex_unlock(&mutex3);
    }
    else if (currVal == threshold){
        pthread_mutex_lock(&mutex4);
          equalThreshold++;
          pthread_mutex_unlock(&mutex4);
    }
    else{
        
    pthread_mutex_lock(&mutex5);
          belowThreshold++;
          pthread_mutex_unlock(&mutex5);
    }
    

return NULL;
}


void * divide(void *value){
    double num = *(double*) value;

    pthread_mutex_lock(&mutex1);
    printf("Dividing ThreadID= %ld, currentValue= %.6f -- dividing %.6f\n",id++,currVal,num);
    pthread_mutex_unlock(&mutex1);
    
    pthread_mutex_lock(&mutex2);
    currVal/=num;
    pthread_mutex_unlock(&mutex2);
    
    if (currVal > threshold){
        pthread_mutex_lock(&mutex3);    
          aboveThreshold++;
        pthread_mutex_unlock(&mutex3);
    }
    
    else if (currVal == threshold){
        pthread_mutex_lock(&mutex4);
          equalThreshold++;
        pthread_mutex_unlock(&mutex4);  
    }
    else{
        pthread_mutex_lock(&mutex5);
          belowThreshold++;
        pthread_mutex_unlock(&mutex5);  
    }
   

return NULL;
}


void * add(void *value){
    double num = *(double*) value;

    pthread_mutex_lock(&mutex1);

    printf("Adding ThreadID= %ld, currentValue= %.6f -- Adding %.6f\n",id++,currVal,num);
   pthread_mutex_unlock(&mutex1);
   
   pthread_mutex_lock(&mutex2);
    currVal+=num;
    pthread_mutex_unlock(&mutex2);
    
    if (currVal > threshold){
        pthread_mutex_lock(&mutex3);    
          aboveThreshold++;
        pthread_mutex_unlock(&mutex3);
    }
    
    else if (currVal == threshold){
        pthread_mutex_lock(&mutex4);
          equalThreshold++;
        pthread_mutex_unlock(&mutex4);  
    }
    else{
        pthread_mutex_lock(&mutex5);
          belowThreshold++;
        pthread_mutex_unlock(&mutex5);  
    }

return NULL;
}


void * subtract(void *value){
    double num = *(double*) value;

    pthread_mutex_lock(&mutex1);
    printf("Subtracting ThreadID= %ld, currentValue= %.6f -- subtracting %.6f\n",id++,currVal,num);
   pthread_mutex_unlock(&mutex1);
   
   pthread_mutex_lock(&mutex2);
    currVal-=num;
    pthread_mutex_unlock(&mutex2);
    
    if (currVal > threshold){
        pthread_mutex_lock(&mutex3);    
          aboveThreshold++;
        pthread_mutex_unlock(&mutex3);
    }
    
    else if (currVal == threshold){
        pthread_mutex_lock(&mutex4);
          equalThreshold++;
        pthread_mutex_unlock(&mutex4);  
    }
    else{
        pthread_mutex_lock(&mutex5);
          belowThreshold++;
        pthread_mutex_unlock(&mutex5);  
    }

return NULL;
}


int main(int argc, char* argv[]){

  long multicount,divcount,addcount,subcount;
  double multivalue,divvalue,addvalue,subvalue;

    if(argc != 3){
        cout<<"Wrong number of arguments passed.\n";
        return 0;
    }

    string t1 = argv[1], t2 = argv[2];
    initVal = stod(t1);
    currVal = initVal;
    threshold = stod(t2);


    ifstream infile("in.txt");
    infile>>multicount>>multivalue;
    infile>>divcount>>divvalue;
    infile>>addcount>>addvalue;
    infile>>subcount>>subvalue;
    infile.close();


    pthread_t *multi_thread = new pthread_t[multicount];
    pthread_t *div_thread = new pthread_t[divcount];

    for(long i=0;i<multicount;i++){
        pthread_create(&multi_thread[i], NULL, multiply, (void*)&multivalue);
    }

    for(long i=0;i<divcount;i++){
        pthread_create(&div_thread[i], NULL, divide, (void*)&divvalue);
    }


    for(long i=0;i<multicount;i++){
        pthread_join(multi_thread[i], NULL);
    }

    for(long i=0;i<divcount;i++){
        pthread_join(div_thread[i], NULL);
    }


    pthread_t *add_thread = new pthread_t[addcount];
    pthread_t *sub_thread = new pthread_t[subcount];

    for(long i=0;i<addcount;i++){
        pthread_create(&add_thread[i], NULL, add, (void*)&addvalue);
    }

    for(long i=0;i<subcount;i++){
        pthread_create(&sub_thread[i], NULL, subtract, (void*)&subvalue);
    }


   for(long i=0;i<addcount;i++){
        pthread_join(add_thread[i], NULL);
    }

    for(long i=0;i<subcount;i++){
        pthread_join(sub_thread[i], NULL);
    }



    ofstream outfile("out.txt");

    outfile<<"Main: Number of Multipliers="<<multicount
    <<", Amount to multiply="<<fixed<<setprecision(6)<<multivalue<<'\n';

    outfile<<"Main: Number of Dividers="<<divcount
    <<", Amount to be divided="<<fixed<<setprecision(6)<<divvalue<<'\n';

    outfile<<"Main: Number of Adders="<<addcount
    <<", Amount to be added="<<fixed<<setprecision(6)<<addvalue<<'\n';

    outfile<<"Main: Number of Subtractor="<<subcount
    <<", Amount to be subtracted="<<fixed<<setprecision(6)<<subvalue<<'\n';

    outfile<<"Main: finalValue="<<fixed<<setprecision(6)
    <<currVal<<setprecision(0)
    <<", belowThreshold="<<belowThreshold
    <<", above Threshold="<<aboveThreshold<<", equle Threshold="<<equalThreshold<<'\n';

    outfile.close();

    return 0;
}
